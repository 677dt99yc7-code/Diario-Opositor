import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Play, Pause, Square, ChevronLeft, ChevronRight, Plus, X,
  FolderClosed, ArrowLeft, Target, Flame, Gauge, Pencil, Trash2,
  Check, RotateCcw, Loader2, Settings2, ChevronDown, ChevronUp,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, Cell,
} from "recharts";

// ---- Design tokens ----
const C = {
  bg: "#12161A",
  surface: "#1B2127",
  surface2: "#20272E",
  border: "#2A323A",
  amber: "#C79A3D",
  olive: "#4C7A5B",
  text: "#ECE8E1",
  muted: "#8B939B",
  danger: "#B5583F",
  rest: "#4A525A",
};

const PALETTE = ["#C79A3D", "#B5583F", "#6E8CAE", "#9B7FB8", "#4C7A5B", "#3A9188", "#3E7CA6", "#C97B63"];

const FONT_IMPORT =
  "@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500;700&display=swap');";

const STORAGE_KEY = "diario-opositor-data";

const DEFAULT_TEMAS = [
  { id: "const", name: "Derecho Constitucional", color: "#C79A3D", goal: 4 },
  { id: "penal", name: "Derecho Penal", color: "#B5583F", goal: 4 },
  { id: "admin", name: "Derecho Administrativo", color: "#6E8CAE", goal: 3 },
  { id: "psico", name: "Psicotécnicos", color: "#9B7FB8", goal: 2 },
  { id: "running", name: "Running", color: "#4C7A5B", goal: 3 },
  { id: "fuerza", name: "Fuerza / Gimnasio", color: "#3A9188", goal: 2 },
  { id: "natacion", name: "Natación", color: "#3E7CA6", goal: 2 },
];

const DEFAULT_DATA = {
  temas: DEFAULT_TEMAS,
  plan: {},
  sesiones: [],
  notas: [],
  tests: {}, // temaId -> [{id, score, date, note}]
};

function todayStr(d = new Date()) {
  return d.toISOString().slice(0, 10);
}
function fmtTime(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return [h, m, s].map((v) => String(v).padStart(2, "0")).join(":");
}
function fmtHoursShort(totalSeconds) {
  const h = totalSeconds / 3600;
  return h.toFixed(1).replace(".0", "") + "h";
}
const WEEK_LABELS = ["L", "M", "X", "J", "V", "S", "D"];
const MONTH_LABELS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

export default function DiarioOpositorPersistente() {
  const now = new Date();
  const [data, setData] = useState(DEFAULT_DATA);
  const [loaded, setLoaded] = useState(false);
  const [saveState, setSaveState] = useState("idle"); // idle | saving | saved | error
  const [activeTab, setActiveTab] = useState("hoy");

  // ---- Load from persistent storage ----
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get(STORAGE_KEY, false);
        if (res && res.value) {
          const parsed = JSON.parse(res.value);
          setData({ ...DEFAULT_DATA, ...parsed });
        }
      } catch (e) {
        // no data yet — use defaults
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  // ---- Save (debounced) ----
  const saveTimer = useRef(null);
  useEffect(() => {
    if (!loaded) return;
    setSaveState("saving");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        setSaveState(result ? "saved" : "error");
      } catch (e) {
        setSaveState("error");
      }
    }, 500);
    return () => saveTimer.current && clearTimeout(saveTimer.current);
  }, [data, loaded]);

  const update = useCallback((fn) => setData((prev) => fn(prev)), []);

  async function resetAll() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
    } catch (e) {}
    setData(DEFAULT_DATA);
  }

  if (!loaded) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center" style={{ background: C.bg, color: C.muted }}>
        <style>{FONT_IMPORT}</style>
        <Loader2 className="animate-spin" size={22} />
      </div>
    );
  }

  const tabs = [
    { id: "hoy", label: "Hoy" },
    { id: "calendario", label: "Calendario" },
    { id: "apuntes", label: "Apuntes" },
    { id: "progreso", label: "Progreso" },
  ];

  return (
    <div className="min-h-screen w-full flex flex-col" style={{ background: C.bg, color: C.text, fontFamily: "'Inter', sans-serif" }}>
      <style>{FONT_IMPORT}</style>

      <header className="px-5 pt-6 pb-4 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.border}` }}>
        <div>
          <div style={{ fontFamily: "'Oswald', sans-serif", letterSpacing: "0.06em" }} className="text-xs uppercase">
            <span style={{ color: C.muted }}>Diario de</span> <span style={{ color: C.amber }}>Opositor</span>
          </div>
          <div style={{ fontFamily: "'Oswald', sans-serif" }} className="text-2xl font-semibold mt-0.5">
            {tabs.find((t) => t.id === activeTab)?.label}
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <div className="text-xs px-2.5 py-1.5 rounded" style={{ background: C.surface, border: `1px solid ${C.border}`, color: C.muted, fontFamily: "'JetBrains Mono', monospace" }}>
            {now.toLocaleDateString("es-ES", { weekday: "short", day: "2-digit", month: "short" }).toUpperCase()}
          </div>
          <span className="text-[10px]" style={{ color: saveState === "error" ? C.danger : C.muted }}>
            {saveState === "saving" && "guardando…"}
            {saveState === "saved" && "guardado"}
            {saveState === "error" && "error al guardar"}
          </span>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-5 py-5 pb-24">
        {activeTab === "hoy" && <HoyTab data={data} update={update} />}
        {activeTab === "calendario" && <CalendarioTab data={data} update={update} />}
        {activeTab === "apuntes" && <ApuntesTab data={data} update={update} />}
        {activeTab === "progreso" && <ProgresoTab data={data} update={update} />}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 flex justify-around py-2.5" style={{ background: C.surface, borderTop: `1px solid ${C.border}` }}>
        {tabs.map((t) => {
          const active = activeTab === t.id;
          return (
            <button key={t.id} onClick={() => setActiveTab(t.id)} className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-md">
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: active ? C.amber : "transparent" }} />
              <span className="text-[11px] uppercase" style={{ fontFamily: "'Oswald', sans-serif", letterSpacing: "0.04em", color: active ? C.amber : C.muted }}>
                {t.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}

// ---------------- HOY ----------------
function HoyTab({ data, update }) {
  const { temas, plan, sesiones } = data;
  const dateKey = todayStr();
  const todayTemaId = plan[dateKey];
  const todayTema = temas.find((t) => t.id === todayTemaId);

  const [timerTemaId, setTimerTemaId] = useState(temas[0]?.id || "");
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (running) intervalRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    else if (intervalRef.current) clearInterval(intervalRef.current);
    return () => intervalRef.current && clearInterval(intervalRef.current);
  }, [running]);

  useEffect(() => {
    if (!timerTemaId && temas.length) setTimerTemaId(temas[0].id);
  }, [temas, timerTemaId]);

  function stopAndLog() {
    if (elapsed > 0 && timerTemaId) {
      update((prev) => ({
        ...prev,
        sesiones: [...prev.sesiones, { id: `s${Date.now()}`, temaId: timerTemaId, dateStr: dateKey, seconds: elapsed }],
      }));
    }
    setRunning(false);
    setElapsed(0);
  }

  const todayTotals = useMemo(() => {
    const totals = {};
    sesiones.filter((s) => s.dateStr === dateKey).forEach((s) => (totals[s.temaId] = (totals[s.temaId] || 0) + s.seconds));
    return totals;
  }, [sesiones, dateKey]);
  const todaySeconds = Object.values(todayTotals).reduce((a, b) => a + b, 0);

  if (temas.length === 0) {
    return <EmptyState text="No tienes bloques creados todavía. Ve a Calendario → Editar bloques para crear el primero." />;
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-lg p-5" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-2 mb-2">
          <Target size={14} color={C.amber} />
          <span className="text-[11px] uppercase" style={{ color: C.amber, fontFamily: "'Oswald', sans-serif", letterSpacing: "0.08em" }}>Bloque de hoy</span>
        </div>
        {todayTemaId === "descanso" ? (
          <div style={{ fontFamily: "'Oswald', sans-serif" }} className="text-xl font-semibold">Día de descanso</div>
        ) : todayTema ? (
          <>
            <div style={{ fontFamily: "'Oswald', sans-serif" }} className="text-xl font-semibold">{todayTema.name}</div>
            <div className="text-sm mt-1" style={{ color: C.muted }}>Objetivo semanal: {todayTema.goal}h</div>
          </>
        ) : (
          <div className="text-sm" style={{ color: C.muted }}>Aún no has asignado un bloque a hoy — hazlo en Calendario.</div>
        )}
        <div className="mt-3 text-xs px-2 py-1 rounded inline-block" style={{ background: C.surface2, color: C.muted }}>
          Hoy has estudiado: <span style={{ color: C.text, fontFamily: "'JetBrains Mono', monospace" }}>{fmtHoursShort(todaySeconds)}</span>
        </div>
      </div>

      <div className="rounded-lg p-5 flex flex-col items-center gap-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <select
          value={timerTemaId}
          onChange={(e) => setTimerTemaId(e.target.value)}
          disabled={running}
          className="w-full text-sm rounded px-3 py-2"
          style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }}
        >
          {temas.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>

        <div className="text-5xl font-bold tabular-nums" style={{ fontFamily: "'JetBrains Mono', monospace", color: running ? C.amber : C.text }}>
          {fmtTime(elapsed)}
        </div>

        <div className="flex gap-3 w-full">
          {!running ? (
            <button onClick={() => setRunning(true)} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md font-semibold text-sm" style={{ background: C.amber, color: C.bg, fontFamily: "'Oswald', sans-serif" }}>
              <Play size={16} fill={C.bg} /> START
            </button>
          ) : (
            <button onClick={() => setRunning(false)} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md font-semibold text-sm" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}`, fontFamily: "'Oswald', sans-serif" }}>
              <Pause size={16} /> PAUSA
            </button>
          )}
          <button onClick={stopAndLog} disabled={elapsed === 0} className="flex-1 flex items-center justify-center gap-2 py-3 rounded-md font-semibold text-sm" style={{ background: "transparent", color: elapsed === 0 ? C.muted : C.olive, border: `1px solid ${elapsed === 0 ? C.border : C.olive}`, fontFamily: "'Oswald', sans-serif" }}>
            <Square size={14} /> GUARDAR
          </button>
        </div>
      </div>

      {Object.keys(todayTotals).length > 0 && (
        <div className="flex flex-col gap-2">
          <span className="text-[11px] uppercase" style={{ color: C.muted, fontFamily: "'Oswald', sans-serif", letterSpacing: "0.06em" }}>Registrado hoy</span>
          {Object.entries(todayTotals).map(([temaId, secs]) => {
            const tema = temas.find((t) => t.id === temaId);
            if (!tema) return null;
            return (
              <div key={temaId} className="flex items-center justify-between px-3 py-2 rounded" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: tema.color }} />
                  <span className="text-sm">{tema.name}</span>
                </div>
                <span className="text-sm" style={{ fontFamily: "'JetBrains Mono', monospace", color: C.muted }}>{fmtTime(secs)}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ---------------- CALENDARIO ----------------
function CalendarioTab({ data, update }) {
  const now = new Date();
  const [calYear, setCalYear] = useState(now.getFullYear());
  const [calMonth, setCalMonth] = useState(now.getMonth());
  const [selectedDay, setSelectedDay] = useState(todayStr());
  const [editingBlocks, setEditingBlocks] = useState(false);

  const { temas, plan } = data;
  const selectedTemaId = plan[selectedDay];

  const monthDays = useMemo(() => {
    const firstOfMonth = new Date(calYear, calMonth, 1);
    const startOffset = (firstOfMonth.getDay() + 6) % 7;
    const numDays = new Date(calYear, calMonth + 1, 0).getDate();
    const cells = [];
    for (let i = 0; i < startOffset; i++) cells.push(null);
    for (let d = 1; d <= numDays; d++) cells.push(d);
    return cells;
  }, [calYear, calMonth]);

  function changeMonth(delta) {
    let m = calMonth + delta, y = calYear;
    if (m < 0) { m = 11; y -= 1; }
    if (m > 11) { m = 0; y += 1; }
    setCalMonth(m); setCalYear(y);
  }

  function assignTema(dateStr, temaId) {
    update((prev) => ({ ...prev, plan: { ...prev.plan, [dateStr]: temaId } }));
  }
  function clearDay(dateStr) {
    update((prev) => { const p = { ...prev.plan }; delete p[dateStr]; return { ...prev, plan: p }; });
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <button onClick={() => changeMonth(-1)} className="p-2 rounded" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
          <ChevronLeft size={16} color={C.text} />
        </button>
        <span style={{ fontFamily: "'Oswald', sans-serif" }} className="text-lg font-medium capitalize">{MONTH_LABELS[calMonth]} {calYear}</span>
        <button onClick={() => changeMonth(1)} className="p-2 rounded" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
          <ChevronRight size={16} color={C.text} />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {WEEK_LABELS.map((w) => <div key={w} className="text-center text-[10px]" style={{ color: C.muted, fontFamily: "'Oswald', sans-serif" }}>{w}</div>)}
        {monthDays.map((d, i) => {
          if (d === null) return <div key={i} />;
          const dateStr = todayStr(new Date(calYear, calMonth, d));
          const temaId = plan[dateStr];
          const tema = temaId === "descanso" ? { color: C.rest } : temas.find((t) => t.id === temaId);
          const selected = dateStr === selectedDay;
          const today = dateStr === todayStr();
          return (
            <button key={i} onClick={() => setSelectedDay(dateStr)} className="aspect-square rounded flex flex-col items-center justify-center gap-1 text-xs"
              style={{ background: selected ? C.surface2 : C.surface, border: `1px solid ${selected ? C.amber : C.border}`, color: today ? C.amber : C.text }}>
              <span>{d}</span>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: tema ? tema.color : "transparent" }} />
            </button>
          );
        })}
      </div>

      <div className="rounded-lg p-4 flex flex-col gap-3" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <div className="text-sm" style={{ color: C.muted }}>
          {new Date(selectedDay).toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" })}
          {selectedDay === todayStr() && <span style={{ color: C.amber }}> · hoy</span>}
        </div>
        <div className="flex flex-wrap gap-2">
          {temas.map((t) => (
            <button key={t.id} onClick={() => assignTema(selectedDay, t.id)} className="text-[11px] px-2.5 py-1.5 rounded-full flex items-center gap-1.5"
              style={{ background: selectedTemaId === t.id ? t.color + "26" : C.surface2, border: `1px solid ${selectedTemaId === t.id ? t.color : C.border}`, color: selectedTemaId === t.id ? t.color : C.muted }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: t.color }} />{t.name}
            </button>
          ))}
          <button onClick={() => assignTema(selectedDay, "descanso")} className="text-[11px] px-2.5 py-1.5 rounded-full"
            style={{ background: selectedTemaId === "descanso" ? C.surface2 : "transparent", border: `1px solid ${C.border}`, color: C.muted }}>
            Descanso
          </button>
          {selectedTemaId && (
            <button onClick={() => clearDay(selectedDay)} className="text-[11px] px-2.5 py-1.5 rounded-full flex items-center gap-1" style={{ border: `1px solid ${C.border}`, color: C.muted }}>
              <X size={11} /> Quitar
            </button>
          )}
        </div>
      </div>

      <button onClick={() => setEditingBlocks((v) => !v)} className="flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm"
        style={{ border: `1px solid ${C.border}`, color: C.muted }}>
        <Settings2 size={14} /> {editingBlocks ? "Cerrar edición de bloques" : "Editar bloques"}
      </button>

      {editingBlocks && <BloquesEditor data={data} update={update} />}
    </div>
  );
}

function BloquesEditor({ data, update }) {
  const { temas } = data;
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [draft, setDraft] = useState({ name: "", goal: 2, color: PALETTE[0] });

  function startEdit(t) {
    setEditingId(t.id);
    setDraft({ name: t.name, goal: t.goal, color: t.color });
  }

  function saveEdit(id) {
    update((prev) => ({
      ...prev,
      temas: prev.temas.map((t) => (t.id === id ? { ...t, name: draft.name.trim() || t.name, goal: Number(draft.goal) || t.goal, color: draft.color } : t)),
    }));
    setEditingId(null);
  }

  function deleteTema(id) {
    update((prev) => {
      const plan = { ...prev.plan };
      Object.keys(plan).forEach((k) => { if (plan[k] === id) delete plan[k]; });
      const tests = { ...prev.tests };
      delete tests[id];
      return {
        ...prev,
        temas: prev.temas.filter((t) => t.id !== id),
        plan,
        sesiones: prev.sesiones.filter((s) => s.temaId !== id),
        notas: prev.notas.filter((n) => n.temaId !== id),
        tests,
      };
    });
    if (editingId === id) setEditingId(null);
  }

  function addTema() {
    if (!newName.trim()) return;
    const id = `t${Date.now()}`;
    const color = PALETTE[data.temas.length % PALETTE.length];
    update((prev) => ({ ...prev, temas: [...prev.temas, { id, name: newName.trim(), color, goal: 2 }] }));
    setNewName("");
  }

  return (
    <div className="rounded-lg p-4 flex flex-col gap-3" style={{ background: C.surface2, border: `1px solid ${C.border}` }}>
      {temas.map((t) => (
        <div key={t.id} className="rounded-lg p-3" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
          {editingId === t.id ? (
            <div className="flex flex-col gap-2">
              <input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                className="text-sm rounded px-3 py-2" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
              <div className="flex items-center gap-2">
                <span className="text-xs" style={{ color: C.muted }}>Objetivo semanal (h)</span>
                <input type="number" min="0" value={draft.goal} onChange={(e) => setDraft({ ...draft, goal: e.target.value })}
                  className="text-sm rounded px-2 py-1 w-16" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {PALETTE.map((c) => (
                  <button key={c} onClick={() => setDraft({ ...draft, color: c })} className="w-6 h-6 rounded-full" style={{ background: c, border: draft.color === c ? `2px solid ${C.text}` : "2px solid transparent" }} />
                ))}
              </div>
              <div className="flex gap-2 mt-1">
                <button onClick={() => saveEdit(t.id)} className="flex-1 py-1.5 rounded text-xs font-medium flex items-center justify-center gap-1" style={{ background: C.amber, color: C.bg }}><Check size={13} /> Guardar</button>
                <button onClick={() => setEditingId(null)} className="flex-1 py-1.5 rounded text-xs" style={{ background: C.surface2, color: C.muted, border: `1px solid ${C.border}` }}>Cancelar</button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: t.color }} />
                <div>
                  <div className="text-sm">{t.name}</div>
                  <div className="text-[11px]" style={{ color: C.muted }}>{t.goal}h/semana</div>
                </div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => startEdit(t)} className="p-1.5 rounded" style={{ color: C.muted }}><Pencil size={14} /></button>
                <button onClick={() => deleteTema(t.id)} className="p-1.5 rounded" style={{ color: C.danger }}><Trash2 size={14} /></button>
              </div>
            </div>
          )}
        </div>
      ))}

      <div className="flex gap-2">
        <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nombre del nuevo bloque"
          className="flex-1 text-sm rounded px-3 py-2" style={{ background: C.surface, color: C.text, border: `1px solid ${C.border}` }} />
        <button onClick={addTema} className="px-3 rounded flex items-center gap-1 text-sm font-medium" style={{ background: C.amber, color: C.bg }}>
          <Plus size={15} /> Crear
        </button>
      </div>
    </div>
  );
}

// ---------------- APUNTES ----------------
function ApuntesTab({ data, update }) {
  const { temas, notas } = data;
  const [openFolder, setOpenFolder] = useState(null);
  const [addingNote, setAddingNote] = useState(false);
  const [noteDraft, setNoteDraft] = useState({ title: "", content: "" });

  if (temas.length === 0) return <EmptyState text="No tienes bloques creados. Créalos en Calendario → Editar bloques para poder guardar apuntes." />;

  if (!openFolder) {
    return (
      <div className="grid grid-cols-2 gap-3">
        {temas.map((t) => {
          const count = notas.filter((n) => n.temaId === t.id).length;
          return (
            <button key={t.id} onClick={() => setOpenFolder(t.id)} className="rounded-lg p-4 flex flex-col items-start gap-3 text-left" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <FolderClosed size={20} color={t.color} />
              <div>
                <div className="text-sm font-medium leading-tight">{t.name}</div>
                <div className="text-[11px] mt-1" style={{ color: C.muted }}>{count} nota{count !== 1 ? "s" : ""}</div>
              </div>
            </button>
          );
        })}
      </div>
    );
  }

  const tema = temas.find((t) => t.id === openFolder);
  if (!tema) { setOpenFolder(null); return null; }
  const folderNotes = notas.filter((n) => n.temaId === openFolder);

  function saveNote() {
    if (!noteDraft.title.trim()) return;
    update((prev) => ({ ...prev, notas: [...prev.notas, { id: `n${Date.now()}`, temaId: openFolder, title: noteDraft.title, content: noteDraft.content }] }));
    setNoteDraft({ title: "", content: "" });
    setAddingNote(false);
  }
  function deleteNote(id) {
    update((prev) => ({ ...prev, notas: prev.notas.filter((n) => n.id !== id) }));
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <button onClick={() => { setOpenFolder(null); setAddingNote(false); }} className="p-2 rounded" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
          <ArrowLeft size={16} color={C.text} />
        </button>
        <span className="w-2 h-2 rounded-full" style={{ background: tema.color }} />
        <span style={{ fontFamily: "'Oswald', sans-serif" }} className="text-base font-medium">{tema.name}</span>
      </div>

      {folderNotes.map((n) => (
        <div key={n.id} className="rounded-lg p-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
          <div className="flex items-start justify-between gap-2">
            <div className="text-sm font-medium mb-1">{n.title}</div>
            <button onClick={() => deleteNote(n.id)} style={{ color: C.muted }}><X size={14} /></button>
          </div>
          <div className="text-xs" style={{ color: C.muted, whiteSpace: "pre-wrap" }}>{n.content}</div>
        </div>
      ))}

      {addingNote ? (
        <div className="rounded-lg p-4 flex flex-col gap-2" style={{ background: C.surface, border: `1px solid ${C.amber}` }}>
          <input autoFocus placeholder="Título" value={noteDraft.title} onChange={(e) => setNoteDraft({ ...noteDraft, title: e.target.value })}
            className="text-sm rounded px-3 py-2" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
          <textarea placeholder="Escribe tu apunte..." value={noteDraft.content} onChange={(e) => setNoteDraft({ ...noteDraft, content: e.target.value })} rows={4}
            className="text-sm rounded px-3 py-2 resize-none" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
          <div className="flex gap-2 mt-1">
            <button onClick={saveNote} className="flex-1 py-2 rounded text-sm font-medium" style={{ background: C.amber, color: C.bg }}>Guardar</button>
            <button onClick={() => setAddingNote(false)} className="flex-1 py-2 rounded text-sm" style={{ background: C.surface2, color: C.muted, border: `1px solid ${C.border}` }}>Cancelar</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setAddingNote(true)} className="flex items-center justify-center gap-2 py-3 rounded-lg text-sm" style={{ border: `1px dashed ${C.border}`, color: C.muted }}>
          <Plus size={15} /> Nueva nota
        </button>
      )}
    </div>
  );
}

// ---------------- PROGRESO (horas + tests) ----------------
function ProgresoTab({ data, update }) {
  const { temas, sesiones, tests } = data;
  const [expanded, setExpanded] = useState(null);

  const weekStart = useMemo(() => {
    const d = new Date();
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const weekTotals = useMemo(() => {
    const totals = {};
    temas.forEach((t) => (totals[t.id] = 0));
    sesiones.forEach((s) => { if (new Date(s.dateStr) >= weekStart) totals[s.temaId] = (totals[s.temaId] || 0) + s.seconds; });
    return totals;
  }, [sesiones, weekStart, temas]);

  const totalHoursByTema = useMemo(() => {
    const totals = {};
    temas.forEach((t) => (totals[t.id] = 0));
    sesiones.forEach((s) => { totals[s.temaId] = (totals[s.temaId] || 0) + s.seconds; });
    return totals;
  }, [sesiones, temas]);

  const chartData = temas.map((t) => ({ name: t.name.split(" ")[0], full: t.name, horas: +((weekTotals[t.id] || 0) / 3600).toFixed(2), color: t.color }));

  function avgScore(temaId) {
    const arr = tests[temaId] || [];
    if (arr.length === 0) return null;
    return arr.reduce((a, b) => a + b.score, 0) / arr.length;
  }

  function diagnostic(tema) {
    const avg = avgScore(tema.id);
    const totalHrs = (totalHoursByTema[tema.id] || 0) / 3600;
    if (avg === null) return { text: "Aún sin tests registrados", tone: C.muted };
    if (avg < 5) {
      if (totalHrs < tema.goal) return { text: "Vas mal — y le dedicas poco tiempo: mete más horas", tone: C.danger };
      return { text: "Vas mal a pesar de las horas — cambia de método de estudio", tone: C.danger };
    }
    if (avg < 7) return { text: "Vas regular, en la media", tone: C.amber };
    if (totalHrs < tema.goal * 0.6) return { text: "Vas muy bien y con pocas horas — gran ritmo", tone: C.olive };
    return { text: "Vas muy bien, mantén el ritmo", tone: C.olive };
  }

  function addTest(temaId, score, note) {
    if (score === "" || isNaN(score)) return;
    update((prev) => ({
      ...prev,
      tests: {
        ...prev.tests,
        [temaId]: [...(prev.tests[temaId] || []), { id: `q${Date.now()}`, score: Number(score), date: todayStr(), note: note || "" }],
      },
    }));
  }
  function deleteTest(temaId, id) {
    update((prev) => ({ ...prev, tests: { ...prev.tests, [temaId]: (prev.tests[temaId] || []).filter((q) => q.id !== id) } }));
  }

  if (temas.length === 0) return <EmptyState text="No tienes bloques creados. Créalos en Calendario → Editar bloques." />;

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-lg p-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-2 mb-3">
          <Gauge size={14} color={C.amber} />
          <span className="text-[11px] uppercase" style={{ color: C.amber, fontFamily: "'Oswald', sans-serif", letterSpacing: "0.08em" }}>Horas esta semana</span>
        </div>
        <div style={{ width: "100%", height: 180 }}>
          <ResponsiveContainer>
            <BarChart data={chartData} margin={{ top: 4, right: 4, left: -22, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
              <XAxis dataKey="name" tick={{ fill: C.muted, fontSize: 10 }} axisLine={{ stroke: C.border }} tickLine={false} />
              <YAxis tick={{ fill: C.muted, fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: C.surface2, border: `1px solid ${C.border}`, borderRadius: 6, fontSize: 12 }} labelStyle={{ color: C.text }} formatter={(v, n, props) => [`${v}h`, props.payload.full]} />
              <Bar dataKey="horas" radius={[3, 3, 0, 0]}>{chartData.map((d, i) => <Cell key={i} fill={d.color} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Flame size={14} color={C.amber} />
          <span className="text-[11px] uppercase" style={{ color: C.muted, fontFamily: "'Oswald', sans-serif", letterSpacing: "0.06em" }}>Tests por tema</span>
        </div>

        {temas.map((t) => {
          const avg = avgScore(t.id);
          const diag = diagnostic(t);
          const isOpen = expanded === t.id;
          const entries = tests[t.id] || [];
          return (
            <div key={t.id} className="rounded-lg overflow-hidden" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <button onClick={() => setExpanded(isOpen ? null : t.id)} className="w-full flex items-center justify-between px-3 py-3">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: t.color }} />
                  <div className="text-left">
                    <div className="text-sm">{t.name}</div>
                    <div className="text-[11px]" style={{ color: C.muted }}>
                      {((totalHoursByTema[t.id] || 0) / 3600).toFixed(1)}h totales
                      {avg !== null && <> · nota media {avg.toFixed(1)}</>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] px-2 py-1 rounded-full" style={{ color: diag.tone, background: diag.tone + "1f" }}>{diag.text}</span>
                  {isOpen ? <ChevronUp size={14} color={C.muted} /> : <ChevronDown size={14} color={C.muted} />}
                </div>
              </button>

              {isOpen && (
                <div className="px-3 pb-3 flex flex-col gap-2" style={{ borderTop: `1px solid ${C.border}` }}>
                  {entries.length > 0 && (
                    <div className="flex flex-col gap-1.5 mt-2">
                      {entries.map((q) => (
                        <div key={q.id} className="flex items-center justify-between text-xs px-2.5 py-1.5 rounded" style={{ background: C.surface2 }}>
                          <span style={{ color: C.text }}>{q.date} · nota <b>{q.score}</b>{q.note && <span style={{ color: C.muted }}> — {q.note}</span>}</span>
                          <button onClick={() => deleteTest(t.id, q.id)} style={{ color: C.muted }}><X size={12} /></button>
                        </div>
                      ))}
                    </div>
                  )}
                  <TestForm onAdd={(score, note) => addTest(t.id, score, note)} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="text-[11px] text-center px-4" style={{ color: C.muted }}>
        El diagnóstico usa una regla simple (nota media + horas vs objetivo). En la versión final, esto lo haría una IA
        analizando tus resultados y tu evolución real por tema.
      </div>
    </div>
  );
}

function TestForm({ onAdd }) {
  const [score, setScore] = useState("");
  const [note, setNote] = useState("");
  return (
    <div className="flex flex-col gap-2 mt-1">
      <div className="flex gap-2">
        <input type="number" min="0" max="10" step="0.1" placeholder="Nota (0-10)" value={score} onChange={(e) => setScore(e.target.value)}
          className="w-28 text-sm rounded px-3 py-2" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
        <input placeholder="Nota rápida (opcional)" value={note} onChange={(e) => setNote(e.target.value)}
          className="flex-1 text-sm rounded px-3 py-2" style={{ background: C.surface2, color: C.text, border: `1px solid ${C.border}` }} />
      </div>
      <button onClick={() => { onAdd(score, note); setScore(""); setNote(""); }} className="py-2 rounded text-sm font-medium flex items-center justify-center gap-1.5" style={{ background: C.amber, color: C.bg }}>
        <Plus size={14} /> Añadir resultado de test
      </button>
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div className="rounded-lg p-6 text-center text-sm" style={{ background: C.surface, border: `1px dashed ${C.border}`, color: C.muted }}>
      {text}
    </div>
  );
}
