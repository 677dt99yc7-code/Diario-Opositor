# Diario Opositor

Aplicación web móvil basada en el proyecto TSX original. Los datos se guardan en el almacenamiento local del navegador del dispositivo.

## Publicación
Este repositorio está preparado para GitHub Pages mediante GitHub Actions.
